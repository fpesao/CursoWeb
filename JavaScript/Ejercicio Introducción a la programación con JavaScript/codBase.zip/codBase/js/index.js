
document.getElementById('boton-receta1').addEventListener('click', function(){





})

document.getElementById('boton-receta2').addEventListener('click', function(){






})
